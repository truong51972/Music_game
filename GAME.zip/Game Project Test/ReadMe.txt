Code là ở file main.cpp.
Sử dụng nút D,F,J,K để chơi nha.
Game yêu cầu sử dụng tất cả các .dll để chơi.
Game chơi tốt nhất ở màn hình 1920x1080, ai hong có thì hoi 😂.